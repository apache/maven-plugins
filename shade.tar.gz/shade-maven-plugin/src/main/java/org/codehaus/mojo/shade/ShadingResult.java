package org.codehaus.mojo.shade;

/** @author Jason van Zyl */
public class ShadingResult
{
}
