package org.codehaus.mojo.shade;

import org.codehaus.plexus.util.*;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );

        StringUtils.isEmpty( "foo" );
    }
}
