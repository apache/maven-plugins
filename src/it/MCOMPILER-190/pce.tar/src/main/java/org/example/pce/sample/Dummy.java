package org.example.pce.sample;

public class Dummy {
	public static void main(final String[] args) {
		String dummy = new Integer(1);
	}
}
