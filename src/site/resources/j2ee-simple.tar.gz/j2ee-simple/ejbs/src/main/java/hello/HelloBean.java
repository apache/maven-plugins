package hello;

import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

public class HelloBean implements SessionBean {

	public void ejbActivate() {
	}

	public void ejbCreate() {
	}

	public void ejbPassivate() {
	}

	public void ejbRemove() {
	}

	public String sayHello(String myName) throws EJBException {
		return ("Hello " + myName);
	}

	public void setSessionContext(SessionContext ctx) {
	}
}
